
/**
 *  This function for allow letters and full stop only
 */
$(".allow-name").on("keypress keyup blur", function (event) {
    var $this = $(this);
    $this.val($(this).val().replace(/[^a-z A-Z\. ]/g, ''));
});
//-----------------------------------END CODES OF ALLOW LETTERS AND FULL STOP ONLY--------------------------------------

/**
 *  This function for allow numbers only
 */

$(".tel-p").on("keypress keyup blur", function (event) {
    var $this = $(this);
    $this.val($(this).val().replace(/[^+0-9]/g, ''));
});

//--------------------------------------END CODE OF ALLOW NUMBERS-------------------------------------------------------

/**
 * This function for allow date inputs
 */
$('.allow-date').on('keypress keyup blur', function (event) {
    let $this = $(this);
    $this.val($(this).val().replace(/[^/+0-9]/g, ''));
});

//--------------------------------------END CODE OF ALLOW DATE INPUTS---------------------------------------------------

/**
 * This function for allow number and z or x for nic number
 */

$(".nic").on("keypress keyup blur", function (event) {
    var $this = $(this);
    $this.val($(this).val().replace(/[^0-9xXVv]/g, ''));
});

//--------------------------------------END CODE OF ALLOW NUMBER AND Z OR X FOR NIC NUMBER------------------------------

/**
 *  This function for allow numeric only
 */

$(".allow-number ").on("keypress keyup blur", function (event) {
    var $this = $(this);
    $this.val($(this).val().replace(/[^0-9/]/g, ''));
});

//---------------------------------------END CODES OF ALLOW LETTERS AND FULL STOP ONLY----------------------------------
/**
 *  This function for allow numeric and dash only
 */

$(".allow-number-dash ").on("keypress keyup blur", function (event) {
    var $this = $(this);
    $this.val($(this).val().replace(/[^0-9\-]/g, ''));

});

//---------------------------------------END CODES OF ALLOW LETTERS AND FULL STOP ONLY----------------------------------

/**
 * This function for allow Uppercase letters only
 */
$(".allow-capital-letters").on("keypress keyup blur", function (event) {
    var $this = $(this);
    $this.val($(this).val().replace(/^[A-Z]*$/g, ''));
});

//----------------------------------------------------END FUNCTION------------------------------------------------------

/**
 * This function for allow the Numeric values With Decimal Point
 */

$(".allow-numeric-with-decimal ,.rate").on("keypress keyup ", function (event) {

    var $this = $(this);

    $this.val($(this).val().replace(/[^0-9\.]/g, ''));

    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57) &&
        (event.which != 0 && event.which != 8)) {
        event.preventDefault();
    }

    var text = $this.val();

    if ((event.which == 46) && (text.indexOf('.') == -1)) {
        setTimeout(function () {
            if ($this.val().substring($this.val().indexOf('.')).length > 3) {
                $this.val($this.val().substring(0, $this.val().indexOf('.') + 3));
            }
        }, 1);
    }

    if ((text.indexOf('.') != -1) &&
        (text.substring(text.indexOf('.')).length > 2) &&
        (event.which != 0 && event.which != 8) &&
        ($(this)[0].selectionStart >= text.length - 2)) {
        event.preventDefault();
    }
});

//-----------------------------END CODES OF ALLOW THE NUMERIC VALUES WITH DECIMAL POINTS--------------------------------

/**
 * This function for allow the numeric values with decimal point in paste event
 */

$('.allow-numeric-with-decimal,.rate').bind("paste", function (e) {
    var text = e.originalEvent.clipboardData.getData('Text');
    if ($.isNumeric(text)) {
        if ((text.substring(text.indexOf('.')).length > 3) && (text.indexOf('.') > -1)) {
            e.preventDefault();
            $(this).val(text.substring(0, text.indexOf('.') + 3));
        }
    } else {
        e.preventDefault();
    }
});
//------------------------END CODES OF ALLOW THE NUMERIC VALUES WITH DECIMAL POINT IN PASTE EVENT-----------------------

/**
 * This function for adding decimal points for allow-numeric-with-decimal class
 */

$(".allow-numeric-with-decimal").on("blur", function (event) {
// function addZeroes(num) {

    var num = $(this).val();

    var result = (parseFloat(num) || 0).toFixed(2);
    $(this).val(result);


});

//------------------------END CODES OF ADDING DECIMAL POINTS FOR ALLOW-NUMERIC-WITH-DECIMAL CLASS-----------------------

/**
 *  This function for adding decimal points for rate class
 */

$(".rate").on("blur", function (event) {
// function addZeroes(num) {
    var num = $(this).val();
    if ($(this).val().includes('.')) {

        var result = (parseFloat(num) || 0).toFixed(2);
        $(this).val(result);

    } else {
        $(this).val($(this).val());
    }

});

//-------------------------------END CODES OF ADDING DECIMAL POINTS FOR RATE CLASS--------------------------------------

/**
 * this function for numeric values without decimal point
 */

$(".allow-numeric-without-decimal").on("keypress keyup blur", function (event) {
    $(this).val($(this).val().replace(/[^\d].+/, ""));
    if ((event.which < 48 || event.which > 57)) {
        event.preventDefault();
    }
});

//---------------------------END CODES OF NUMERIC VALUES WITHOUT DECIMAL POINT------------------------------------------

/**
 * This method for validate names
 */

function validateNames(nameText) {
    let regExp = /^[a-zA-Z]+(([a-zA-Z ])?[a-zA-Z]*)*$/;
    return regExp.test(nameText);
}

//-------------------------------------------END CODES OF VALIDATE NAMES------------------------------------------------

/**
 *  This method for validate initials
 */

function validateInitials(initialText) {
    console.log(initialText);
    let regExp = /^[A-Za-z .]+$/;
    return regExp.test(initialText);
}

//------------------------------------------END CODES OF VALIDATE INITIALS----------------------------------------------

/**
 * This method for validate nic
 */

function validateNic(nicText) {
    // let regExp = /^(?:19|20)?\d{2}(?:[01235678]\d\d(?<!(?:000|500|36[7-9]|3[7-9]\d|86[7-9]|8[7-9]\d)))\d{4}(?:[vVxX])$/;
    let regExp = /^([0-9]{9}[x|X|v|V]|[0-9]{12})$/;
    return regExp.test(nicText);
}

//--------------------------------------------END CODES OF VALIDATE NIC-------------------------------------------------

/**
 *  This function for validate mobile numbers
 */

function validateMobileOrTelephoneNumbers(mobileNumberText) {
    let regExp = /^(?:0)?(?:(11|21|23|24|25|26|27|31|32|33|34|35|36|37|38|41|45|47|51|52|54|55|57|63|65|66|67|81|91)(0|2|3|4|5|7|9)|7(0|1|2|5|6|7|8)\d)\d{6}$/;
    return regExp.test(mobileNumberText);
}

//--------------------------------------------END CODES OF VALIDATE MOBILE NUMBERS--------------------------------------
/**
 * This method for validate email
 */

function validateEmail(email) {
    let re = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    return re.test(email);
}

//---------------------------------------------END CODES OF VALIDATE EMAIL----------------------------------------------

/**
 *  This function for validate email
 */

function validateEmails(emailText) {
    let regExp = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/
    return regExp.test(emailText);
}

//---------------------------------------------END CODES OF VALIDATE EMAILS---------------------------------------------

/**
 * This function for validate Address
 */
function validateAddress(addressText) {
    let regExp = /^[.0-9a-zA-Z\s,-\/]+$/;
    return regExp.test(addressText);
}

//------------------------------------------END CODE OF VALIDATE ADDRESS------------------------------------------------

/**
 * This function for validate rates
 */
function validateRates(textValue) {
    let regExp = /^[\d]+(\.\d{1,2})?$/;
    return regExp.test(textValue);
}

//------------------------------------------------------ END CODE ------------------------------------------------------
/**
 * This function for validate Numbers and letters only
 */
function validateLetterAndNumbers(textValue) {
    let regExp = /^[a-zA-Z0-9 ]*$/;
    return regExp.test(textValue);
}

//------------------------------------------------------ END CODE ------------------------------------------------------


/**
 * This function for validate Numbers and letters without space only
 */
function validateLetterAndNumbersWithoutSpace(textValue) {

    let regExp = /^[a-zA-Z0-9]*$/;
    return regExp.test(textValue);
}

//------------------------------------------------------ END CODE ------------------------------------------------------
/**
 * This function for validate date
 */
function isValidDate(dateText) {
    // var bits = dateText.split('/');
    var bits = dateText.split('-');
    // var d = new Date(bits[2], bits[1] - 1, bits[0]);
    var d = new Date(bits[0], bits[1] - 1, bits[2]);
    return d && (d.getMonth() + 1) == bits[1];
}

//---------------------------------------------END CODES OF VALIDATE DATE-----------------------------------------------
/**
 * This function for check future date or not
 */

function isFutureDate(idate) {
    var today = new Date().getTime(),
        idate = idate.split("/");
    // idate = idate.split("-");


    idate = new Date(idate[2], idate[1] - 1, idate[0]).getTime();
    // idate = new Date(idate[0], idate[1] - 1, idate[2]).getTime();
    return (today - idate) < 0;
}

function checkDate(field, errorSpan) {

    let idate = field.val();

    let dateReg = /^(0[1-9]|[12][0-9]|3[01])[\/](0[1-9]|1[012])[\/]19[2-9][0-9]|20[0-9][0-9]$/;
    // let dateReg = /^19[2-9][0-9]|20[0-9][0-9][-](0[1-9]|1[012])[-](0[1-9]|[12][0-9]|3[01])$/;


    if (idate == "") {
        if (field.hasClass('border-danger')) {
            field.removeClass('border-danger1');
        }
        errorSpan.html("").addClass('text-danger');
    }

    // alert(dateReg.test(idate))
    if (dateReg.test(idate)) {

        if (field.hasClass('border-danger')) {
            field.removeClass('border-danger text-danger');
        }
        errorSpan.html("").addClass('text-danger');
        if (isFutureDate(idate)) {
            field.addClass('border-danger text-danger');
            errorSpan.html("It's a future date !").addClass('text-danger');

        } else {


            if (field.hasClass('border-danger text-danger')) {
                field.removeClass('border-danger text-danger');
            }
            errorSpan.html("").addClass('text-danger');
            // callNameTxt.focus();
        }
    } else {

        if (idate == "") {


            if (field.hasClass('border-danger')) {
                field.removeClass('border-danger1');
            }
            errorSpan.html("").addClass('text-danger');
        } else {

            field.addClass('border-danger');
            errorSpan.html("Invalid date !").addClass('text-danger');
        }
    }
}

//-----------------------------------------END CODES OF CHECK FUTURE DATE OR NOT----------------------------------------

/**
 * This function for check the selector is empty or not select an option
 */

function checkSelector(selector, errorMessageSpan, focusField) {

    if (selector.children('option').length > 1) {
        if (selector.hasClass('border-danger')) {
            selector.removeClass('border-danger');
            errorMessageSpan.text('');
        }

        if (selector.val() == "0") {

            selector.addClass('border-danger');
            errorMessageSpan.text('please select..!').addClass('text-danger');
            return false;
        } else {

            selector.removeClass('border-danger');
            errorMessageSpan.text('');
            focusField.focus();
            return true;
        }
        return false;
    } else {
        selector.addClass('border-danger');
        errorMessageSpan.text('There are no options').addClass('text-danger');
        return true;
    }
}

//------------------------------------------------END FUNCTION----------------------------------------------------------

/**
 * This function for check the validation of email field
 */

function checkValidationOfAddress(textField, errorMessage, focusField) {

    let addressText = textField.val().trim();
    let textLength = addressText.length;
    if ((!(textLength <= 3)) || textLength == 0) {
        if (validateAddress(addressText)) {
            if (textField.hasClass('border-danger')) {
                textField.removeClass('border-danger');
            }
            errorMessage.html("");
            $(focusField).focus();
            return true;
        } else {
            if (!(textField.hasClass('border-danger'))) {
                textField.addClass('border-danger');
            }
            errorMessage.html("Enter the valid address..!").addClass('text-danger');
            return false;
        }
    } else {
        if (!(textField.hasClass('border-danger'))) {
            textField.addClass('border-danger');
        }
        errorMessage.html("This is not an address..!").addClass('text-danger');
        return false;
    }
}

//---------------------------------------END CODE OF CHECK VALIDATION OF ADDRESS----------------------------------------

/**
 * This function for check the validation of telephone number
 */

function checkValidationOfTelephoneNumber(textField, errorMessage, focusField) {

    let telephoneNoText = textField.val().trim();
    if (validateMobileOrTelephoneNumbers(telephoneNoText)) {
        if (textField.hasClass('border-danger')) {
            textField.removeClass('border-danger');
        }
        focusField.focus();
        errorMessage.html("");
        return true;
    } else {
        if (!(textField.hasClass('border-danger'))) {
            textField.addClass('border-danger');
        }
        errorMessage.html("Enter the valid contact no").addClass('text-danger');
        return false;
    }
}

//------------------------------------END CODES OF CHECK VALIDATION OF TELEPHONE NUMBER---------------------------------

/**
 * This function for check the validation of email field
 */

function checkValidationOfEmail(textField, errorMessage, focusField) {

    let emailText = textField.val().trim();
    let textLength = emailText.length;
    if (!(textLength <= 5)) {
        if (validateEmails(emailText)) {
            if (textField.hasClass('border-danger')) {
                textField.removeClass('border-danger');
            }
            errorMessage.html("");
            $(focusField).focus();
            return true;
        } else {
            if (!(textField.hasClass('border-danger'))) {
                textField.addClass('border-danger');
            }
            errorMessage.html("Enter the valid email..!").addClass('text-danger');
            return false;
        }
    } else {
        if (!(textField.hasClass('border-danger'))) {
            textField.addClass('border-danger');
        }
        errorMessage.html("This email is too short..!").addClass('text-danger');
        return false;
    }
}

//---------------------------------------END CODES OF CHECK VALIDATION OF EMAIL-----------------------------------------
/**
 * This function for check the validations of Names
 */

function checkValidationOfName(textField, errorMessage, focusField) {

    let nameText = textField.val();
    let textLength = nameText.length;
    if (!(textLength <= 5)) {
        if (validateNames(nameText)) {
            if (textField.hasClass('border-danger')) {
                textField.removeClass('border-danger');
            }
            errorMessage.html("");
            $(focusField).focus();
            return true;
        } else {
            if (!(textField.hasClass('border-danger'))) {
                textField.addClass('border-danger');
            }
            errorMessage.html("Enter the valid name").addClass('text-danger');
            return false;
        }
    } else {
        if (!(textField.hasClass('border-danger'))) {
            textField.addClass('border-danger');
        }
        errorMessage.html("Enter the minimum 6 characters ").addClass('text-danger');
        return false;
    }
}

//--------------------------------------END CODES OF CHECK VALIDATION OF NAME-------------------------------------------

/**
 * This function check validation of initials
 */

function checkValidationOfInitials(initialsField, errorSpan) {
    let initials = initialsField.val();

    if (validateInitials(initials)) {
        if (initialsField.hasClass('border-danger')) {
            initialsField.removeClass('border-danger');
        }
        initialsField.addClass('border-success');
        errorSpan.html("");
        $(otherRefNo).focus();
        return true;
    } else {
        if (!(initialsField.hasClass('border-danger'))) {
            initialsField.addClass('border-danger');
        }
        initialsField.removeClass('border-success');
        errorSpan.html("Invalid initials").addClass('text-danger');
        return false;
    }
}

//------------------------------------END CODES OF CHECK VALIDATION OF INITIALS-----------------------------------------

/**
 * This function for check validation of nic
 */

function checkValidationOfNicNo(nicNoField, errorSpan) {
    let nicNo = nicNoField.val();

    if (validateNic(nicNo)) {
        if (nicNoField.hasClass('border-danger')) {
            nicNoField.removeClass('border-danger');
        }
        errorSpan.html("");
        // $(prefixType).focus();
        return true;
    } else {
        if (!(nicNoField.hasClass('border-danger'))) {
            nicNoField.addClass('border-danger');
        }

        errorSpan.html("Invalid Nic No").addClass('text-danger');
        return false;
    }
}

//------------------------------------END CODES OF CHECK VALIDATION OF NIC NO-------------------------------------------

/**
 *  This function for check validation of name
 */

function checkValidationOfNames(nameField, errorSpan) {
    let surName = nameField.val();

    if (validateNames(surName)) {
        if (nameField.hasClass('border-danger')) {
            nameField.removeClass('border-danger');
        }
        nameField.addClass('border-success');
        errorSpan.html("");
        $().focus();
        return true;
    } else {
        if (!(nameField.hasClass('border-danger'))) {
            nameField.addClass('border-danger');
        }
        nameField.removeClass('border-success');
        errorSpan.html("Invalid Name").addClass('text-danger');
        return false;
    }
}

//----------------------------------------END CODES OF CHECK VALIDATION OF NAME-----------------------------------------

/**
 * This function for check the selector is empty
 */

function checkSelectorIsEmpty(selector, errorMessageLabel) {
    if (selector.has('options').length > 0) {
        errorMessageLabel.html("").removeClass('text-danger');
        return true;
    } else {
        errorMessageLabel.html("There are no option to select ..!").addClass('text-danger');
        return false;
    }
}

//---------------------------------------END CODE FOR CHECK SELECTOR IS EMPTY FUNCTION----------------------------------

/**
 * This function for check the field is empty
 */

function checkFieldIsEmpty(field, errorMessageLabel) {
    let value = field.val().trim();
    if (value == "") {
        if (!(field.hasClass('border-danger'))) {
            field.addClass('border-danger');

        }
        field.removeClass('border-success');
        return true;
    } else {
        if (field.hasClass('border-danger')) {
            field.removeClass('border-danger');
        }
        return false;
    }
}

//------------------------------------START CODE FOR SET ENTER KEY EVENT TO THE INPUT FIELDS----------------------------

/**
 * This function for set focus function to given field
 */

function focusFieldsByEnterAction(focusField, event) {
    if (event.keyCode == 13) {
        focusField.focus();
        console.log(focusField)
    }
}

//-------------------------------END CODE FOR SET ENTER KEY EVENT TO THE INPUT FILEDS-----------------------------------

/**
 * This function for set Toasts Messages
 */

function showToasts(type, message) {
    console.log(type + "st")
    switch (type) {
        case true:
            showToast(TOAST_TYPE.SUCCESS, "Success !", message);
            break;
        case 'false':
            showToast(TOAST_TYPE.DANGER, " Error !", "Action Not Complete..!")
            break;
    }
}

//------------------------------------------------END FUNCTION----------------------------------------------------------

/**
 * This function for manage toast alerts
 */

function toastPreparing(field, textFieldValue, code, message) {
    if (field == "Save") {

        if (textFieldValue == code) {

            showToasts(true, "New " + message + " Has Been Added..!");
        } else {

            showToasts(false, "Action Not Complete..!");
        }
    } else {

        if (textFieldValue == code) {
            showToasts(true, message + "Has Been Updated..!");
        } else {
            showToasts(false, "Action Not Complete..!");
        }
    }
}

//--------------------------------------------------END FUNCTION--------------------------------------------------------


/**
 * This function for clear the border color and error message
 */

function clearBorderAndErrorMessage( inputField, errorMessageSpan) {

    // focusField.focus();
    inputField.attr('style', 'border-color: #ccc  !important')

    errorMessageSpan.html("").attr('style', 'color: black');
}

//------------------------------------------------END FUNCTION----------------------------------------------------------

/**
 * This function for check file format
 */
function checkFileFormat(field, errorMessageSpan) {
    let extension = field.val().split('.').pop();
    if (['png', 'jpg', 'jpeg', 'PNG', 'JPG', 'JPEG', 'PDF', 'DOC', 'DOCX', 'pdf', 'doc', 'docx'].indexOf(extension) > -1) {
        if (errorMessageSpan.hasClass('text-danger')) {
            errorMessageSpan.html("").removeClass("text-danger");
        }
        return true;
    } else {
        errorMessageSpan.html("Please Select the correct file format").addClass('text-danger');
        return false;
    }
}

//-------------------------------------------------END FUNCTION---------------------------------------------------------

/**
 * This function for convert date
 */
function dateFormat(date) {
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let month1 = (date.getMonth() > 8) ? (date.getMonth() + 1) : ('0' + (date.getMonth() + 1));
    let day1 = (date.getDate() > 9) ? date.getDate() : ('0' + date.getDate());
    // let formatDate = year + "-" + appendLeadingZeroes(month) + "-" + appendLeadingZeroes(day);
    let formatDate = day1 + "/" + month1 + "/" + year;
    return formatDate;
}

//-------------------------------------------------END FUNCTION---------------------------------------------------------

/**
 *  change date format separate "/"
 */
function dateFormators(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [day, month, year].join('/');
}

//--------------------------------------------------------END FUNCTION--------------------------------------------------
/**
 *  change date format separate "-"
 */
function formatDate(date) {

    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [day, month, year].join('-');
}
//--------------------------------------------------------END FUNCTION--------------------------------------------------
/**
 *   validation date format
 */
function dateChange(date) {

    var d = new Date(date.value),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),


        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    $('#' + date.id).val([day, month, year].join('-'));
}


//--------------------------------------------------------END FUNCTION--------------------------------------------------

/**
 *  error messages validations
 */

function setSuccessFor(input) {
    const formControl = input.parentElement;//form-group
    formControl.className = 'form-group success'

}

//--------------------------------------------------------END FUNCTION--------------------------------------------------

function setErrorFor(input, message) {
    const formControl = input.parentElement;//form-group
    console.log(input);
    const small = formControl.querySelector('small');
    //add error message inside small

    //add error class
    small.innerText = message;
    //add error class
    formControl.className = 'form-group  error';
}
//--------------------------------------------------------END FUNCTION--------------------------------------------------
/**
 *  set date picker class
 */
$('.date').datepicker({
    format: 'yyyy/mm/dd',
    autoclose: true
});
//--------------------------------------------------------END FUNCTION--------------------------------------------------

